sub fooD {
	my $self = shift;
	
    print(123);
}

1;
