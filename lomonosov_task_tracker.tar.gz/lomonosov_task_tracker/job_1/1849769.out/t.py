a = 0

while True:
    a += 1
    print(a)
    if a == 5:
        break
