from PyQuantum.Tools.LoadPackage import load_pkg
import sys

config_path = sys.argv[1]
config = load_pkg(config_path, config_path)

# import os
# print(os.getcwd())


# print(sys.argv[1])

# print(config.wc)
