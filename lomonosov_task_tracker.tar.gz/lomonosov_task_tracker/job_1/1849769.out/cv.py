# assert 1 == 2, "wc < 0"
# import pandas as pd
# from PyQuantum.JC.Cavity import *
from cv2 import *

f()
# 1 == 1

# Assert(1 == 2, '1==2', FILE(), LINE())

# cv = Cavity(wc=-1, wa=1, g=1, n_atoms=1)

# cv.info()

# data = [[str(cv.wc) + ' Hz'], [str(cv.wa) + ' Hz'],
#         [str(cv.g) + ' Hz'], [], [cv.n_atoms], [cv.n_levels]]
# a = pd.DataFrame(data, columns=None, index=[
#     'wc', 'wa', 'g', '', 'n_atoms', 'n_levels'])

# print(a)
