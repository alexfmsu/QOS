#!/bin/bash

export PYTHONPATH=~/software/Python/bin

${PYTHONPATH}/python3.7 test_sc.py
