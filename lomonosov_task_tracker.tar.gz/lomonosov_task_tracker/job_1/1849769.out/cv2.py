from PyQuantum.JC.Cavity import *


def f():
    # assert 1 == 2, "wc < 0"
    cv = Cavity(wc=-1, wa=1, g=1, n_atoms=1)
