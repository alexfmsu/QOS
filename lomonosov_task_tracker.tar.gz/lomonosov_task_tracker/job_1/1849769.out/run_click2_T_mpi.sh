#!/bin/bash

# echo $PATH
# echo $PWD

# working
# export PYTHON_PATH=~/_scratch/software/python/bin



# export PYTHONPATH=../software/python/bin
# pwd ../software/python/bin
# export PYTHONPATH=/mnt/data/users/dm4/vol12/alexfmsu_1945/usr/bin
export PYTHONPATH=~/software/Python/bin
# export PYTHONPATH=/mnt/data/users/dm4/vol12/alexfmsu_2131/software/Python/bin
# echo ${PYTHONPATH}
# pwd
# rm sink.out 2>/dev/null || true
# ${PYTHON_PATH}/python3.7 sink3d_mpi.py
# echo 123
# ls -a $HOME
# pwd
# echo 123
# ${PYTHONPATH}/python3.7 -c
# echo ${BASH_ALIASES[PYTHONPATH]}
# pwd
${PYTHONPATH}/python3.7 click2_T_mpi.py
# ${PYTHONPATH}/python3.7 click2_mpi.py
# ~/software/Python/bin/python3.7 click2.py
# ${BASH_ALIASES[PYTHON_PATH]}/python3.7 sink3d_mpi.py
# ${BASH_ALIASES[PYTHON_PATH]}/python3.7 click2.py

# cd ../software
# pwd
# ls
# chdir usr
# pwd
# python3.7 -V


# /mnt/data/users/dm4/vol12/alexfmsu_1945/usr/bin/python3.7 -V

# chdir('~')

# python3 -V

# echo $HOME/usr/bin
# ../../usr/bin/python3.7 -V
# $($HOME"/usr/bin/python3.7 -V")
# ~/usr/bin/python3.7 sink_g_l.py
