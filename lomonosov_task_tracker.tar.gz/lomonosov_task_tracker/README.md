# lomonosov_task_tracker
Task tracker for Lomonosov supercomputer (Moscow State University)
